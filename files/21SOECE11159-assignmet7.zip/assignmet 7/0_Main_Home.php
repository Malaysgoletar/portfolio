<!DOCTYPE html>
<html>
<title>PHP Tutorial 7</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container w3-center w3-border w3-border-black">
  <h2>Exersises List</h2>
 
  <ul class="w3-ul w3-hoverable w3-center">
    <li> 
        <a href="1_Grade_Marks.php" target="_blank"> 1_Grade_Marks.php</a>
    </li>

    <li> 
        <a href="2_Max_Three.php" target="_blank">2_Max_Three</a>
    </li>

    <li> 
        <a href="3_Car_Price.php" target="_blank">3_Car_Price</a>
    </li>

    <li> 
        <a href="4_Unit_Bill.php" target="_blank">4_Unit_Bill</a>
    </li>

    <li> 
        <a href="5_Calculator_Post.php" target="_blank">5_Calculator_Post</a>
    </li>
   
  </ul>
</div>

</body>
</html>
